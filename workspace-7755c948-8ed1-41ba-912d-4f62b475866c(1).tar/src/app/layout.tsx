import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Muhammad Arslan Shafique | AI Web Developer & AI Automation Developer",
  description:
    "Building premium business websites and AI-powered automation solutions for modern businesses. Hire Muhammad Arslan Shafique for your next project.",
  keywords: [
    "AI Web Developer",
    "AI Automation Developer",
    "Premium Websites",
    "Business Solutions",
    "Freelance Developer",
    "Next.js Developer",
    "Tailwind CSS",
    "n8n Automation",
  ],
  authors: [{ name: "Muhammad Arslan Shafique" }],
  openGraph: {
    title:
      "Muhammad Arslan Shafique | AI Web Developer & AI Automation Developer",
    description:
      "Building premium business websites and AI-powered automation solutions for modern businesses.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
      </body>
    </html>
  );
}