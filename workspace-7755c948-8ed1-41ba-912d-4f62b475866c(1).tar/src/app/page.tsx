'use client';

import Navigation from '@/components/portfolio/Navigation';
import Hero from '@/components/portfolio/Hero';
import About from '@/components/portfolio/About';
import Projects from '@/components/portfolio/Projects';
import Services from '@/components/portfolio/Services';
import TechStack from '@/components/portfolio/TechStack';
import WhyWorkWithMe from '@/components/portfolio/WhyWorkWithMe';
import Contact from '@/components/portfolio/Contact';
import Footer from '@/components/portfolio/Footer';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navigation />
      <main className="flex-1">
        <Hero />
        <div className="section-divider" />
        <About />
        <div className="section-divider" />
        <Projects />
        <div className="section-divider" />
        <Services />
        <div className="section-divider" />
        <TechStack />
        <div className="section-divider" />
        <WhyWorkWithMe />
        <div className="section-divider" />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}