'use client';

import { motion } from 'framer-motion';
import { ArrowUp, Heart } from 'lucide-react';

const footerLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Projects', href: '#projects' },
  { label: 'Services', href: '#services' },
  { label: 'Contact', href: '#contact' },
];

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavClick = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative border-t border-zinc-100">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12 md:gap-8 items-start">
          {/* Brand */}
          <div className="md:col-span-1">
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                handleNavClick('#home');
              }}
              className="text-2xl font-bold tracking-tight text-zinc-900"
            >
              <span className="gradient-text">MAS</span>
            </a>
            <p className="mt-4 text-sm text-zinc-400 leading-relaxed max-w-xs">
              Building premium business websites and AI-powered automation
              solutions for modern businesses.
            </p>
          </div>

          {/* Navigation */}
          <div className="flex flex-col items-start md:items-center">
            <h4 className="text-sm font-semibold text-zinc-900 mb-4">
              Navigation
            </h4>
            <div className="flex flex-col gap-3">
              {footerLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(link.href);
                  }}
                  className="text-sm text-zinc-400 hover:text-zinc-900 transition-colors duration-300"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="flex flex-col items-start md:items-end">
            <h4 className="text-sm font-semibold text-zinc-900 mb-4">
              Get in Touch
            </h4>
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                handleNavClick('#contact');
              }}
              className="inline-flex items-center px-6 py-2.5 text-sm font-medium text-white bg-zinc-900 rounded-full hover:bg-zinc-800 transition-all duration-300 hover:shadow-[0_4px_20px_rgba(0,0,0,0.12)]"
            >
              Hire Me
            </a>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-zinc-400 flex items-center gap-1">
            &copy; {new Date().getFullYear()} Muhammad Arslan Shafique. Crafted with
            <Heart size={12} className="text-zinc-300 fill-current" />
          </p>
          <button
            onClick={scrollToTop}
            className="group flex items-center gap-2 text-xs text-zinc-400 hover:text-zinc-900 transition-colors duration-300"
          >
            Back to top
            <ArrowUp
              size={12}
              className="group-hover:-translate-y-0.5 transition-transform duration-300"
            />
          </button>
        </div>
      </div>
    </footer>
  );
}