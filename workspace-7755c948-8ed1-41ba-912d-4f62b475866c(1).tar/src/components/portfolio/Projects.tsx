'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'Nova Dental Studio',
    category: 'Luxury Dental Website',
    description:
      'A premium dental clinic website featuring elegant design, online appointment booking, and a sophisticated patient experience crafted to reflect the clinic\'s commitment to excellence.',
    image: '/portfolio/nova-dental.png',
    technologies: ['HTML', 'Tailwind CSS', 'JavaScript', 'Responsive Design'],
    liveUrl: '#',
    codeUrl: '#',
  },
  {
    title: 'Haveli Restaurant',
    category: 'Premium Restaurant Website',
    description:
      'A visually rich restaurant website combining traditional aesthetics with modern web design. Features a warm color palette, food gallery, menu showcase, and reservation system.',
    image: '/portfolio/haveli-restaurant.png',
    technologies: ['HTML', 'Tailwind CSS', 'JavaScript', 'Responsive Design'],
    liveUrl: '#',
    codeUrl: '#',
  },
  {
    title: 'Restaurant Website V2',
    category: 'Modern Restaurant Platform',
    description:
      'A next-generation restaurant website with a dark, sophisticated design. Includes online ordering, menu management, and a glassmorphism-driven UI for an immersive dining experience.',
    image: '/portfolio/restaurant-v2.png',
    technologies: ['HTML', 'Tailwind CSS', 'JavaScript', 'Responsive Design'],
    liveUrl: '#',
    codeUrl: '#',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] },
  },
};

export default function Projects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="projects" className="relative py-28 lg:py-36 bg-zinc-50/50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-2xl"
        >
          <span className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-zinc-400 mb-6">
            Featured Projects
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-zinc-900">
            Selected work
          </h2>
          <p className="mt-4 text-lg text-zinc-400">
            A curated collection of projects that showcase my approach to design and development.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="mt-16 space-y-8"
        >
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              variants={cardVariants}
              className="group relative rounded-3xl border border-zinc-100 bg-white overflow-hidden hover:shadow-[0_8px_40px_rgba(0,0,0,0.06)] transition-all duration-700"
            >
              <div className="grid lg:grid-cols-2 gap-0">
                {/* Project Image */}
                <div className="image-zoom">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 sm:h-80 lg:h-full object-cover"
                  />
                </div>

                {/* Project Details */}
                <div className="p-8 lg:p-12 flex flex-col justify-center">
                  <div className="space-y-4">
                    {/* Category */}
                    <span className="inline-block text-xs font-semibold tracking-[0.15em] uppercase text-zinc-400">
                      {project.category}
                    </span>

                    {/* Title */}
                    <h3 className="text-2xl lg:text-3xl font-bold text-zinc-900 tracking-tight">
                      {project.title}
                    </h3>

                    {/* Description */}
                    <p className="text-sm lg:text-base text-zinc-400 leading-relaxed">
                      {project.description}
                    </p>

                    {/* Technologies */}
                    <div className="flex flex-wrap gap-2 pt-2">
                      {project.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 text-xs font-medium text-zinc-500 bg-zinc-100 rounded-full"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-4 pt-4">
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-white bg-zinc-900 rounded-full hover:bg-zinc-800 transition-all duration-300 hover:shadow-[0_4px_20px_rgba(0,0,0,0.12)]"
                      >
                        <ExternalLink size={14} />
                        View Live Demo
                      </a>
                      <a
                        href={project.codeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-zinc-600 border border-zinc-200 rounded-full hover:border-zinc-400 hover:text-zinc-900 transition-all duration-300"
                      >
                        <Github size={14} />
                        View Code
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Project number */}
              <div className="absolute top-6 right-6 text-7xl font-bold text-zinc-100/80 select-none hidden lg:block">
                {String(index + 1).padStart(2, '0')}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}