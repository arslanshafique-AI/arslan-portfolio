'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  Globe,
  Layout,
  Utensils,
  HeartPulse,
  Bot,
  RefreshCw,
} from 'lucide-react';

const services = [
  {
    icon: Globe,
    title: 'Premium Business Websites',
    description:
      'High-performance websites designed to convert visitors into clients. Clean, fast, and built to scale.',
  },
  {
    icon: Layout,
    title: 'Landing Pages',
    description:
      'Conversion-optimized landing pages that capture leads and drive action with compelling design.',
  },
  {
    icon: Utensils,
    title: 'Restaurant Websites',
    description:
      'Beautiful restaurant websites with menus, reservations, and online ordering capabilities.',
  },
  {
    icon: HeartPulse,
    title: 'Dental Websites',
    description:
      'Professional dental websites that build patient trust and streamline appointment booking.',
  },
  {
    icon: Bot,
    title: 'AI Automation',
    description:
      'Intelligent automation workflows using n8n and AI to eliminate repetitive tasks and boost productivity.',
  },
  {
    icon: RefreshCw,
    title: 'Website Redesign',
    description:
      'Transform outdated websites into modern, high-performing digital experiences that impress.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
};

export default function Services() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="services" className="relative py-28 lg:py-36">
      <div className="max-w-7xl mx-auto px-6 lg:px-8" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="text-center max-w-2xl mx-auto"
        >
          <span className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-zinc-400 mb-6">
            Services
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-zinc-900">
            What I offer
          </h2>
          <p className="mt-4 text-lg text-zinc-400">
            End-to-end solutions tailored to your business needs, from concept to deployment.
          </p>
        </motion.div>

        {/* Services Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6"
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                variants={cardVariants}
                className="group relative p-8 rounded-2xl border border-zinc-100 bg-white hover:border-zinc-200 hover:shadow-[0_4px_24px_rgba(0,0,0,0.04)] transition-all duration-500"
              >
                {/* Icon */}
                <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-zinc-50 text-zinc-400 group-hover:bg-zinc-900 group-hover:text-white transition-all duration-500">
                  <Icon size={22} strokeWidth={1.5} />
                </div>

                {/* Content */}
                <h3 className="mt-6 text-lg font-semibold text-zinc-900">
                  {service.title}
                </h3>
                <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                  {service.description}
                </p>

                {/* Hover arrow */}
                <div className="mt-6 flex items-center gap-2 text-sm font-medium text-zinc-300 group-hover:text-zinc-900 transition-colors duration-500">
                  <span>Learn more</span>
                  <svg
                    className="w-4 h-4 transform group-hover:translate-x-1 transition-transform duration-300"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M17 8l4 4m0 0l-4 4m4-4H3"
                    />
                  </svg>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}