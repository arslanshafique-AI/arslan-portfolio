'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const techStack = [
  { name: 'HTML', icon: '🌐' },
  { name: 'Tailwind CSS', icon: '🎨' },
  { name: 'JavaScript', icon: '⚡' },
  { name: 'n8n', icon: '🤖' },
  { name: 'AI Prompt Engineering', icon: '🧠' },
  { name: 'Responsive Design', icon: '📱' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
};

export default function TechStack() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section className="relative py-28 lg:py-36 bg-zinc-50/50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="text-center max-w-2xl mx-auto"
        >
          <span className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-zinc-400 mb-6">
            Tech Stack
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-zinc-900">
            Tools I work with
          </h2>
          <p className="mt-4 text-lg text-zinc-400">
            Modern technologies and frameworks to deliver exceptional results.
          </p>
        </motion.div>

        {/* Tech Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="mt-16 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-6"
        >
          {techStack.map((tech) => (
            <motion.div
              key={tech.name}
              variants={itemVariants}
              whileHover={{ y: -4, scale: 1.02 }}
              className="group flex flex-col items-center gap-4 p-6 lg:p-8 rounded-2xl border border-zinc-100 bg-white hover:border-zinc-200 hover:shadow-[0_4px_24px_rgba(0,0,0,0.04)] transition-all duration-500"
            >
              <span className="text-3xl lg:text-4xl">{tech.icon}</span>
              <span className="text-sm font-medium text-zinc-600 group-hover:text-zinc-900 transition-colors duration-300 text-center">
                {tech.name}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}