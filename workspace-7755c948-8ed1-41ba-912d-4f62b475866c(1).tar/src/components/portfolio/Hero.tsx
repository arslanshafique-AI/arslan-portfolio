'use client';

import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

export default function Hero() {
  const handleScroll = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden mesh-gradient"
    >
      {/* Subtle decorative elements */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-gradient-to-br from-zinc-100/80 to-transparent rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-gradient-to-tl from-zinc-100/60 to-transparent rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 mb-8 rounded-full border border-zinc-200 bg-white/60 backdrop-blur-sm"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-medium text-zinc-500 tracking-wide uppercase">
                Available for Freelance
              </span>
            </motion.div>

            {/* Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05] text-zinc-900"
            >
              Muhammad{' '}
              <span className="gradient-text">Arslan</span>
              <br />
              Shafique
            </motion.h1>

            {/* Role */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="mt-6 flex flex-col sm:flex-row items-center lg:items-start gap-2 sm:gap-3"
            >
              <span className="text-lg sm:text-xl text-zinc-500 font-light">
                AI Web Developer <span className="text-zinc-300 mx-1">&</span>{' '}
                AI Automation Developer
              </span>
            </motion.div>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="mt-6 text-base sm:text-lg text-zinc-400 max-w-xl mx-auto lg:mx-0 leading-relaxed"
            >
              I build premium business websites and AI-powered automation
              solutions for modern businesses.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="mt-10 flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start"
            >
              <button
                onClick={() => handleScroll('#projects')}
                className="group inline-flex items-center gap-2 px-8 py-3.5 text-sm font-medium text-white bg-zinc-900 rounded-full hover:bg-zinc-800 transition-all duration-300 hover:shadow-[0_8px_30px_rgba(0,0,0,0.12)]"
              >
                View Projects
                <ArrowDown
                  size={16}
                  className="group-hover:translate-y-0.5 transition-transform duration-300"
                />
              </button>
              <button
                onClick={() => handleScroll('#contact')}
                className="inline-flex items-center px-8 py-3.5 text-sm font-medium text-zinc-700 border border-zinc-200 rounded-full hover:border-zinc-400 hover:text-zinc-900 transition-all duration-300 hover:bg-zinc-50"
              >
                Contact Me
              </button>
            </motion.div>
          </div>

          {/* Right - Laptop Mockup */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 1, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="relative hidden lg:block"
          >
            <div className="relative">
              {/* Glow effect behind laptop */}
              <div className="absolute -inset-8 bg-gradient-to-r from-zinc-200/40 via-zinc-100/60 to-zinc-200/40 rounded-3xl blur-2xl" />

              {/* Laptop frame */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-zinc-900/10 border border-zinc-200/60">
                <img
                  src="/portfolio/hero-laptop.png"
                  alt="Premium business website on laptop"
                  className="w-full h-auto object-cover"
                />
              </div>

              {/* Decorative floating elements */}
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-4 -right-4 w-20 h-20 rounded-2xl glass-card flex items-center justify-center shadow-lg"
              >
                <div className="text-center">
                  <div className="text-xl font-bold text-zinc-900">50+</div>
                  <div className="text-[10px] text-zinc-400 font-medium">Projects</div>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
                className="absolute -bottom-4 -left-4 w-24 h-20 rounded-2xl glass-card flex items-center justify-center shadow-lg"
              >
                <div className="text-center">
                  <div className="flex items-center justify-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <svg
                        key={i}
                        className="w-3.5 h-3.5 text-amber-400 fill-current"
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <div className="text-[10px] text-zinc-400 font-medium mt-1">
                    Client Rating
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}