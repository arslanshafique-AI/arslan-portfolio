'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Monitor, Zap, Smartphone, Bot, Code2 } from 'lucide-react';

const reasons = [
  {
    icon: Monitor,
    title: 'Modern UI',
    description: 'Clean, contemporary designs that make a lasting impression.',
  },
  {
    icon: Zap,
    title: 'Fast Delivery',
    description: 'Efficient workflow ensuring your project is delivered on time.',
  },
  {
    icon: Smartphone,
    title: 'Responsive Design',
    description: 'Pixel-perfect experiences across every device and screen size.',
  },
  {
    icon: Bot,
    title: 'AI Powered Workflow',
    description: 'Leveraging AI tools to accelerate development and enhance quality.',
  },
  {
    icon: Code2,
    title: 'Clean Code',
    description: 'Well-structured, maintainable code that scales with your business.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
};

export default function WhyWorkWithMe() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section className="relative py-28 lg:py-36">
      <div className="max-w-7xl mx-auto px-6 lg:px-8" ref={ref}>
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-start">
          {/* Left - Heading */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="lg:sticky lg:top-32"
          >
            <span className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-zinc-400 mb-6">
              Why Work With Me
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-zinc-900 leading-tight">
              Built different.
              <br />
              <span className="text-zinc-400">Delivered better.</span>
            </h2>
            <p className="mt-6 text-lg text-zinc-400 leading-relaxed">
              Every project is crafted with meticulous attention to detail, combining modern design principles with robust engineering to exceed expectations.
            </p>
          </motion.div>

          {/* Right - Reasons Grid */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
            className="space-y-4"
          >
            {reasons.map((reason, index) => {
              const Icon = reason.icon;
              return (
                <motion.div
                  key={reason.title}
                  variants={itemVariants}
                  className="group flex items-start gap-5 p-6 rounded-2xl border border-transparent hover:border-zinc-100 hover:bg-white transition-all duration-500"
                >
                  {/* Icon */}
                  <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-xl bg-zinc-50 text-zinc-400 group-hover:bg-zinc-900 group-hover:text-white transition-all duration-500">
                    <Icon size={20} strokeWidth={1.5} />
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <h3 className="text-base font-semibold text-zinc-900">
                        {reason.title}
                      </h3>
                      <span className="text-xs font-mono text-zinc-300">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                    </div>
                    <p className="mt-2 text-sm text-zinc-400 leading-relaxed">
                      {reason.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </div>
    </section>
  );
}