'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const focusAreas = [
  {
    title: 'Premium Business Websites',
    description: 'High-converting websites that establish credibility and drive growth.',
  },
  {
    title: 'AI Automation',
    description: 'Intelligent workflows that save time and eliminate repetitive tasks.',
  },
  {
    title: 'Frontend Development',
    description: 'Pixel-perfect interfaces with modern frameworks and best practices.',
  },
  {
    title: 'Prompt Engineering',
    description: 'Optimized AI interactions for maximum output quality and efficiency.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
};

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="about" className="relative py-28 lg:py-36">
      <div className="max-w-7xl mx-auto px-6 lg:px-8" ref={ref}>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="max-w-3xl mx-auto text-center"
        >
          {/* Section Label */}
          <motion.span
            variants={itemVariants}
            className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-zinc-400 mb-6"
          >
            About Me
          </motion.span>

          {/* Heading */}
          <motion.h2
            variants={itemVariants}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-zinc-900 leading-tight"
          >
            Crafting digital experiences
            <br />
            <span className="text-zinc-400">that drive real results</span>
          </motion.h2>

          {/* Description */}
          <motion.p
            variants={itemVariants}
            className="mt-8 text-lg text-zinc-500 leading-relaxed max-w-2xl mx-auto"
          >
            I&apos;m Muhammad Arslan Shafique, a passionate AI Web Developer
            and AI Automation Developer based in Pakistan. I specialize in
            building premium business websites and intelligent automation
            solutions that help businesses scale efficiently and stand out
            in the digital landscape.
          </motion.p>
        </motion.div>

        {/* Focus Areas Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="mt-20 grid sm:grid-cols-2 gap-4 lg:gap-6 max-w-4xl mx-auto"
        >
          {focusAreas.map((area, index) => (
            <motion.div
              key={area.title}
              variants={itemVariants}
              className="group relative p-8 rounded-2xl border border-zinc-100 bg-white hover:border-zinc-200 hover:shadow-[0_4px_24px_rgba(0,0,0,0.04)] transition-all duration-500"
            >
              <div className="flex items-start gap-4">
                <span className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-lg bg-zinc-50 text-sm font-semibold text-zinc-400 group-hover:bg-zinc-900 group-hover:text-white transition-all duration-500">
                  {String(index + 1).padStart(2, '0')}
                </span>
                <div>
                  <h3 className="text-base font-semibold text-zinc-900">
                    {area.title}
                  </h3>
                  <p className="mt-2 text-sm text-zinc-400 leading-relaxed">
                    {area.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}